import { forwardRef, useEffect, useImperativeHandle, useMemo, useState } from "react";
import { apiGetBpmnXml } from "../../lib/api";

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

const ZOOM_STEP = 0.1;
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 2.0;

const BpmnStage = forwardRef(function BpmnStage({ sessionId, reloadKey }, ref) {
  const [status, setStatus] = useState("idle"); // idle|loading|ok|fail
  const [text, setText] = useState("");
  const [scale, setScale] = useState(1);

  const title = useMemo(() => {
    if (!sessionId) return "BPMN";
    return `BPMN · ${sessionId}`;
  }, [sessionId]);

  useImperativeHandle(
    ref,
    () => ({
      fit() {
        setScale(1);
      },
      zoomIn() {
        setScale((s) => clamp(Number((s + ZOOM_STEP).toFixed(2)), ZOOM_MIN, ZOOM_MAX));
      },
      zoomOut() {
        setScale((s) => clamp(Number((s - ZOOM_STEP).toFixed(2)), ZOOM_MIN, ZOOM_MAX));
      },
    }),
    []
  );

  useEffect(() => {
    let alive = true;

    async function run() {
      if (!sessionId) {
        setStatus("idle");
        setText("");
        setScale(1);
        return;
      }

      setStatus("loading");
      setText("");

      try {
        const r = await apiGetBpmnXml(sessionId);
        if (!alive) return;

        if (r.ok) {
          setStatus("ok");
          setText(String(r.text || ""));
          setScale(1);
          return;
        }

        setStatus("fail");
        setText(String(r.error || "failed"));
      } catch (e) {
        if (!alive) return;
        setStatus("fail");
        setText(String(e?.message || e));
      }
    }

    run();

    return () => {
      alive = false;
    };
  }, [sessionId, reloadKey]);

  if (!sessionId) {
    return (
      <div className="bpmnStage">
        <div className="bpmnHint">Выбери сессию, затем нажми «Сгенерировать».</div>
      </div>
    );
  }

  return (
    <div className="bpmnStage">
      <div className="bpmnTitle">
        {title}
        {status === "loading" ? <span className="badge">loading…</span> : null}
        {status === "fail" ? <span className="badge err">fail</span> : null}
      </div>

      <div className="bpmnCanvas">
        <div className="bpmnCanvasInner" style={{ transform: `scale(${scale})`, transformOrigin: "0 0" }}>
          <pre className="bpmnPre">{text || ""}</pre>
        </div>
      </div>
    </div>
  );
});

export default BpmnStage;
